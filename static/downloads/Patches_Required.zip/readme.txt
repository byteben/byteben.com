
*******************
!!Patches Required for Collection!!
*******************

Ben Whitmore
May 2018

An SCCM report to clearly display the age of outdated updates against your device collections

Special thanks to Eswar Koneti @eskonr for his public SSRS examples and Adam Gross @adamgrosstx for SQL Ninja skills

Notes:

The report contains one collection, SMSD003 (All Desktop and Server Clients).
Define your own Collections to run the report against by modifying the "COLLID" Parameter and add your collection label and ID in the "Available Values tab

any questions to ben@byteben.com